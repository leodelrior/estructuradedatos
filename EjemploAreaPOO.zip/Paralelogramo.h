#pragma once
class Paralelogramo {
private:
	float basePa;
	float alturaPa;

public:
	Paralelogramo();
	void set_basePa(float _base);
	void set_alturaPa(float _altura);
	float get_basePa();
	float get_alturaPa();
	double areaPa();
};


