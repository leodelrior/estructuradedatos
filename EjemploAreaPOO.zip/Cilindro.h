#pragma once

class Cilindro {
private:
	float radioCilindro;
	float alturaCilindro;
public:
	Cilindro();
	void set_alturaCilindro(float _alturaCilindro);
	void set_radioCilindro(float _radioCilindro);
	float get_alturaCilindro();
	float get_radioCilindro();
	double calcularVolumenCilindro();
};


