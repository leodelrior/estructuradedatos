#pragma once
class Esfera
{
private:
	float radioEsfera;
public:
	Esfera();
	float get_radio();
	void set_radio(float _radio);
	double AreaEsfera();
};


