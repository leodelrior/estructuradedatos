#include "Cilindro.h"

Cilindro::Cilindro() {
}

void Cilindro::set_alturaCilindro(float _alturaCilindro) {
	alturaCilindro = _alturaCilindro;
}
void Cilindro::set_radioCilindro(float _radioCilindro) {
	radioCilindro = _radioCilindro;
}
float Cilindro::get_alturaCilindro() {
	return alturaCilindro;
}
float Cilindro::get_radioCilindro() {
	return radioCilindro;
}
double Cilindro::calcularVolumenCilindro() {
	return 3.1416 * radioCilindro * radioCilindro * alturaCilindro;
}
