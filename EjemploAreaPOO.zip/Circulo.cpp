#include "Circulo.h"
#include <math.h>

Circulo::Circulo() {

}

void Circulo::set_radioC(float _radioCirculo) {
	radioCirculo = _radioCirculo; //El atributo adquiere valor nuevo
}
float Circulo::get_radioC() {
	return radioCirculo; //retorna el valor del radio
}
double Circulo::AreaCirculo() {
	return (pow(radioCirculo, 2) * 3.1415); //retorna el valor del Area
}

